import React, { Component } from 'react';
import B from './B';

class App extends Component {
  state = {
    value: 'not yet updated.'
  };

  handleClick = () => {
    this.setState({ value: ' updated.' });
  };

  render() {
    return (
      <div className='container'>
        <h1>A </h1>
        <B valueToB={this.state.value} handleClickInA={this.handleClick} />
      </div>
    );
  }
}

export default App;
/*  */
