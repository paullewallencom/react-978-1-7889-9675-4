import React, { Component } from 'react';

class C extends Component {
  render() {
    return (
      <div>
        <h1>C (update only) </h1>
        <button
          className='btn btn-primary center-block m-3'
          onClick={this.props.handleClick}
        >
          Click
        </button>
      </div>
    );
  }
}

export default C;
