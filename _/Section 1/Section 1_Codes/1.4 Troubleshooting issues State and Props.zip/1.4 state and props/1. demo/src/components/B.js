import React, { Component } from 'react';
import C from './C';

class B extends Component {
  updateB = () => {
    this.props.update1();
  };

  render() {
    return (
      <div>
        <h1>B (display only): the state is {this.props.valueToB}</h1>
        <C handleClick={this.props.handleClickInA} />
      </div>
    );
  }
}

export default B;
/*<C update={this.props.update2} />*/
