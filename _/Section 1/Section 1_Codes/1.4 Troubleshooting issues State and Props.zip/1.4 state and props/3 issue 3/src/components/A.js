import React, { Component } from 'react';
import B from './B';

class App extends Component {
  state = {
    value1: 'I am the value 1 ',
    value2: 'I am the value 2'
  };

  render() {
    return (
      <div className='container'>
        <B data={this.state} />
      </div>
    );
  }
}

export default App;
