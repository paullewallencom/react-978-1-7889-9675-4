import React, { Component } from 'react';

class B extends Component {
  render() {
    return (
      <div>
        <h1>{this.props.data.value1}</h1>
        <h1>{this.props.data.value2}</h1>
      </div>
    );
  }
}

export default B;
