import React, { Component } from 'react';
import B from './B';

class App extends Component {
  state = {
    value: 1
  };
  handleClick = () => {
    this.setState({ value: this.state.value + 1 });
  };

  render() {
    return (
      <div className='container '>
        <B valueA={this.state.value} />
        <button
          className='btn btn-success center-block m-3'
          onClick={this.handleClick}
        >
          Increment
        </button>
      </div>
    );
  }
}

export default App;
