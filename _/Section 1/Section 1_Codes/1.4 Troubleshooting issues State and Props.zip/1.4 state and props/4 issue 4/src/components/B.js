import React, { Component } from 'react';

class B extends Component {
  constructor(props) {
    super(props);
    this.state = {
      valueB: this.props.valueA,
      valueC: this.props.valueA
    };
  }

  componentDidUpdate(prevProps) {
    if (prevProps.valueA !== this.props.valueA) {
      this.setState({ valueB: this.props.valueA });
    }
  }

  render() {
    return (
      <div>
        <h1>Value A: {this.props.valueA}</h1>
        <h1>value B: {this.state.valueB}</h1>
        <h1>value C: {this.state.valueC}</h1>
      </div>
    );
  }
}

export default B;
