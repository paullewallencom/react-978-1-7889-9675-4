import React, { Component } from 'react';

class Comp2 extends Component {
  render() {
    return (
      <div>
        <h1>I am component 2</h1>
      </div>
    );
  }
}

export default Comp2;
