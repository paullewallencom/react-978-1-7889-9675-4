import React, { Component } from 'react';
import Compo1 from './component1';
import Compo2 from './component2';

class App extends Component {
  render() {
    return (
      <div>
        <Compo1 />
        <Compo2 />
      </div>
    );
  }
}

export default App;
