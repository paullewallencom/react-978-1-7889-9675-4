import React, { Component } from 'react';

class Compo1 extends Component {
  render() {
    return (
      <div>
        <h1>I am component 1</h1>
      </div>
    );
  }
}

export default Compo1;
