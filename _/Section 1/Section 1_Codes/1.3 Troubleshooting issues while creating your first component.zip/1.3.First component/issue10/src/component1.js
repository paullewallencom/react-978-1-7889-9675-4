import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';

class Comp1 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      title1: 'Title 1',
      title2: 'Title 2'
    };
    this.handleFunction = this.handleFunction.bind(this);
  }

  handleFunction() {
    this.setState({
      title1: 'Title 1 changed.'
    });
  }

  handleArrowFunction = () => {
    this.setState({ title2: 'Title 2 changed.' });
  };

  render() {
    return (
      <div className='container'>
        <h1> Bind custom functions </h1>
        <div>
          <h2>{this.state.title1}</h2>
          <button
            className='btn btn-success center-block m-3'
            onClick={this.handleFunction}
          >
            Change the title using bind
          </button>
        </div>
        <div>
          <h2>{this.state.title2}</h2>
          <button
            className='btn btn-success center-block m-3'
            onClick={this.handleArrowFunction}
          >
            Change the title using an arrow function
          </button>
        </div>
      </div>
    );
  }
}

export default Comp1;
