import React, { Component } from 'react';

/*function App(props) {
  return <h1>Hello {props.name}</h1>;
}*/

class App extends Component {
  render() {
    return (
      <div>
        <h1>Hello {this.props.name}</h1>
      </div>
    );
  }
}

export default App;
