import React, { Component } from 'react';
import Compo1 from './component1';

class App extends Component {
  render() {
    return (
      <div>
        <Compo1 />
      </div>
    );
  }
}

export default App;
