import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';

class Comp1 extends Component {
  state = {
    text: 'col-2 text-sm-left'
  };
  render() {
    return (
      <React.Fragment>
        <p className={this.state.text}>
          The Mars Exploration Program (MEP) is a long-term effort to explore
          the planet Mars, funded and led by NASA.
        </p>
        <p className={this.state.text}>
          Formed in 1993, MEP has made use of orbital spacecraft, landers, and
          Mars rovers to explore the possibilities of life on Mars, as well as
          the planet's climate and natural resources.
        </p>
      </React.Fragment>
    );
  }
}

export default Comp1;
