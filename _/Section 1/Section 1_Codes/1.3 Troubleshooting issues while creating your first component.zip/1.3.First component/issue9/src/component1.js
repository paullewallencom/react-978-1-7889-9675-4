import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import objStyle from './componentStyle';

class Comp1 extends Component {
  render() {
    return (
      <>
        <h1 className='m-3'> - Style by a dedicated object: </h1>
        <p className='m-3' style={objStyle}>
          Mars is the fourth planet from the Sun and the second-smallest planet
          in the Solar System after Mercury.
        </p>
        <h1 className='m-3'> - Style by bootstrap: </h1>
        <div className='container'>
          <div className='row'>
            <div className='col'>
              <h1>Col 1</h1>
            </div>
            <div className='col'>
              <h1>Col 2</h1>
            </div>
          </div>
          <div className='row'>
            <div className='col'>
              <h1>Col 3</h1>
            </div>
            <div className='col'>
              <h1>Col 4</h1>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default Comp1;
