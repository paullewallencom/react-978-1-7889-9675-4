const objStyle = {
  fontSize: 50,
  color: '#e77d11'
};

export default objStyle;
