import React, { Component } from 'react';
import Compo1 from './component1';
import Compo2 from './component2';

class App extends Component {
  render() {
    return (
      <>
        <Compo1 />
        <Compo2 />
      </>
    );
  }
}

export default App;
