import React, { Component } from 'react';

class Comp2 extends Component {
  render() {
    return (
      <React.Fragment>
        <h1>I am component 2</h1>
        <h1>I use the React.Fragment</h1>
      </React.Fragment>
    );
  }
}

export default Comp2;
