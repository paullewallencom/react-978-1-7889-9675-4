import React, { Component } from 'react';
import Child from './child';

class App extends Component {
  constructor() {
    super();
    this.state = {
      counter: 0
    };
    this.handleEventParent = this.handleEventParent.bind(this);
  }

  handleEventParent() {
    this.setState({ counter: this.state.counter + 1 });
  }

  render() {
    return (
      <Child
        onClickChild={this.handleEventParent}
        counter={this.state.counter}
      />
    );
  }
}

export default App;
