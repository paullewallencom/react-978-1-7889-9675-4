import React, { Component } from 'react';

class Child extends Component {
  render() {
    return (
      <div className='container'>
        <h1>Counter: {this.props.counter}</h1>
        <button
          onClick={this.props.onClickChild}
          className='btn btn-primary center-block '
        >
          Click to increment
        </button>
      </div>
    );
  }
}

export default Child;
