import React, { Component } from 'react';

class App extends Component {
  constructor() {
    super();

    this.state = {
      counter: 1
    };

    this.handleEventAll = this.handleEventAll.bind(this);
  }

  handleEventAllExplicit(e) {
    const type = e.type;
    console.log('e.type: ', e.type, typeof e);
    switch (type) {
      case 'click':
        console.log('click');
        return;
      case 'mouseenter':
        console.log('mouseenter');
        return;
      case 'mouseleave':
        console.log('mouseleave');
        return;
      default: //do nothing
    }
  }

  handleEventAll({ type }) {
    console.log('type: ', type);
    switch (type) {
      case 'click':
        console.log('click');
        return;
      case 'mouseenter':
        console.log('mouseenter');
        return;
      case 'mouseleave':
        console.log('mouseleave');
        return;
      default: //do nothing
    }
  }

  render() {
    return (
      <div className='container'>
        <button
          className='btn btn-primary center-block m-3'
          onClick={this.handleEventAll}
          onMouseEnter={this.handleEventAll}
          onMouseLeave={this.handleEventAll}
        >
          Click me
        </button>
        <button
          className='btn btn-success center-block m-3'
          onClick={e => {
            this.handleEventAllExplicit(e);
          }}
          onMouseEnter={e => {
            this.handleEventAllExplicit(e);
          }}
          onMouseLeave={e => {
            this.handleEventAllExplicit(e);
          }}
        >
          Click me
        </button>
      </div>
    );
  }
}

export default App;
