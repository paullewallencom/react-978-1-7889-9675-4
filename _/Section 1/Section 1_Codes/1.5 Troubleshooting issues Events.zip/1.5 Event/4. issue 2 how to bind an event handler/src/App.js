import React, { Component } from 'react';

class App extends Component {
  constructor() {
    super();
    this.state = {
      counter: 1
    };
    this.handleEventBindInConstructor = this.handleEventBindInConstructor.bind(
      this
    );
  }

  handleEventBindInRender() {
    console.log('Bound in the render method');
    this.setState({ counter: this.state.counter + 1 });
  }
  handleEventBindInConstructor() {
    console.log('Bound in the constructor');
    this.setState({ counter: this.state.counter + 1 });
  }

  handleEventArrow = () => {
    console.log('an arrow function');
    this.setState({ counter: this.state.counter + 1 });
  };

  render() {
    return (
      <div className='container'>
        <h1> Counter: {this.state.counter}</h1>
        <button
          className='btn btn-primary center-block m-3'
          onClick={this.handleEventBindInRender.bind(this)}
        >
          Click me
        </button>
        <button
          className='btn btn-primary center-block  m-3'
          onClick={this.handleEventBindInConstructor}
        >
          Click me
        </button>
        <button
          className='btn btn-primary center-block  m-3'
          onClick={this.handleEventArrow}
        >
          Click me
        </button>
      </div>
    );
  }
}

export default App;
